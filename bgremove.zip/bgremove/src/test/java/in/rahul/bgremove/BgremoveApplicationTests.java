package in.rahul.bgremove;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BgremoveApplicationTests {

	@Test
	void contextLoads() {
	}

}
